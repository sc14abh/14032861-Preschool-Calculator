//
//  ViewController.swift
//  shaun_PreSchoolApp
//
//  Created by sc14abh on 07/02/2017.
//  Copyright © 2017 sc14abh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var question: UILabel!
  
    @IBOutlet weak var answer: UILabel!
    
    var ans = 0
    var RNG1 = Int(arc4random_uniform(5))
    var RNG2 = Int(arc4random_uniform(5))
    var sum = 0
    
    
    
    @IBAction func button(sender: AnyObject) {
        ans = sender.tag
        if answer == sum {
            self.restart()
        }
        else {
            answer.textColor = UIColor.redColor()
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.greenColor()
        
        sum = RNG1 + RNG2
        question.text = String(RNG1) + " + " + String(RNG2) + " = "
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

